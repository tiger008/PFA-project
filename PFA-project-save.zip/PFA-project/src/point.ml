type t = {x : int; y : int}

let new_point x y = { x = x; y = y }

let iof n = int_of_float n

let foi n = float_of_int n
